module GoldsHelper
end
