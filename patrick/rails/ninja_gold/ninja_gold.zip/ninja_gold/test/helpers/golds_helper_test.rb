require 'test_helper'

class GoldsHelperTest < ActionView::TestCase
end
