class ProductsController < ApplicationController
  def index
    @products = Product.all
  end

  def show
    @product = Product.find(params[:id])
  end

  def new
    @categories = Category.all
  end

  def create
    Product.create(product_params)
    redirect_to '/products'
  end

  def edit
    @categories = Category.all
    @product = Product.find(params[:id])
  end

  def update
    @id = params[:id]
    Product.update(@id, product_params)
    redirect_to "/products/#{@id}"
  end

  def destroy
    Product.destroy(params[:id])
    redirect_to '/products'
  end

  private
  def product_params
    params.require(:product).permit(:category, :name, :description, :price)
  end

end
