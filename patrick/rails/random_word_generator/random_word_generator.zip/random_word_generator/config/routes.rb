Rails.application.routes.draw do
  get '/' => 'words#index'
end
