Rails.application.routes.draw do
  get '/' => 'times#index'
end
